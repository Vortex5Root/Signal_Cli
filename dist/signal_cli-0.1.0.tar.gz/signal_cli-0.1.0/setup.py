# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['signal_cli']

package_data = \
{'': ['*']}

install_requires = \
['datetime>=5.4,<6.0',
 'selenium>=4.17.2,<5.0.0',
 'webdrivermanager>=0.10.0,<0.11.0']

setup_kwargs = {
    'name': 'signal-cli',
    'version': '0.1.0',
    'description': '',
    'long_description': "# Signal-Cli Documentation\n\nThis documentation provides an overview of the Signal-Cli library, which is a Python implementation for interacting with Signal Messenger using the command-line interface (CLI). Signal-Cli allows you to perform various operations such as registering a new account, sending and receiving messages, and retrieving user status.\n\n## Usage\n\nTo use Signal-Cli, you need to have the following prerequisites:\n\n- Python 3.7 or higher\n- Selenium library\n- GeckoDriver (Firefox driver) for Selenium\n\nPlease make sure you have these dependencies installed before proceeding.\n\n## Installation\n\nTo install Signal-Cli, follow these steps:\n\n1. Clone the Signal-Cli repository from GitHub:\n\n```shell\ngit clone https://github.com/Vortex5Root/Signal_Cli/signal-cli.git\n```\n\n2. Navigate to the Signal-Cli directory:\n\n```shell\ncd signal-cli\n```\n\n3. Install the required Python packages:\n\n```shell\npip install -r requirements.txt\n```\n\n4. Download and install GeckoDriver (Firefox driver) for Selenium. Refer to the Selenium documentation for instructions specific to your operating system.\n\n## Examples\n\nThe following examples demonstrate how to use the Signal-Cli library for different operations.\n\n### Account Registration\n\n```python\nimport signal_cli\n\nsignal = signal_cli.SignalCLI()\nsignal.register('+351 929882666')\n```\n\nThis example registers a new Signal account with the phone number '+351 929882666'.\n\n### Sending Messages\n\n```python\nimport signal_cli\n\nsignal = signal_cli.SignalCLI()\nsignal.load = '+351 929882666'  # Load the account with the specified phone number\nsignal.send('+351 910447343', 'Hello, this is a test message.')\n```\n\nThis example sends a message from the loaded account ('+351 929882666') to the recipient '+351 910447343'.\n\n### Receiving Messages\n\n```python\nimport signal_cli\n\nsignal = signal_cli.SignalCLI()\nsignal.load = '+351 929882666'  # Load the account with the specified phone number\nmessages = signal.new_messages\n\nfor message in messages:\n    msg = signal_cli.Message().load_recv(json.loads(message))\n    print(f'From: {msg.from_.phone_number}')\n    print(f'To: {msg.to}')\n    print(f'Message: {msg.message}')\n    print(f'Time Received: {msg.time_rcv}')\n    print(f'Time Sent: {msg.time_send}')\n```\n\nThis example retrieves and displays the received messages for the loaded account.\n\n### Getting User Status\n\n```python\nimport signal_cli\n\nsignal = signal_cli.SignalCLI()\nstatus = signal.getUserStatus('+351 929882666')\nprint(status)\n```\n\nThis example retrieves the status of the user with the phone number '+351 929882666'.\n\n## Class Reference\n\n### `SignalCLI`\n\nThe main class for interacting with Signal Messenger.\n\n#### Properties\n\n- `load` (getter/setter): The phone number of the loaded Signal account.\n\n#### Methods\n\n- `register(number: str, captcha: str = '') -> any`: Registers a new Signal account with the specified phone number and captcha.\n- `send(to: str, message: str) -> list`: Sends a message to the specified recipient.\n- `new_messages() -> list`: Retrieves the new messages for the loaded account.\n- `getUserStatus(number: str) -> list`: Retrieves the status of the user with the specified phone number.\n\n### `Message`\n\nA class representing a Signal message.\n\n#### Properties\n\n- `from_`: The user who sent the message.\n- `to_`: The recipient of the message.\n- `message`: The content of the message.\n- `time_rcv`: The timestamp of when the message was received.\n- `time_send`: The timestamp of when the message was sent.\n\n### `DataValidator`\n\nA class for validating data used in Signal-Cli.\n\n#### Methods\n\n- `is_signal_capthe(url: str) -> bool`: Checks if the given URL is a valid Signal Captcha.\n- `is_phone_number(phone: str) -> bool`: Checks if the given string is a valid phone number.\n\n### `SignalCLI_Exception`\n\nAn exception class for Signal-Cli errors.\n\n#### Properties\n\n- `error_code`: A dictionary mapping error codes to error messages.\n\n#### Methods\n\n- `__init__(self, code, value)`: Initializes the exception with the specified error code and value.\n\n### `User`\n\nA class representing a Signal user.\n\n#### Properties\n\n- `uuid`: The UUID of the user.\n- `phone_number`: The phone number of the user.\n- `username`: The username of the user.\n\n#### Methods\n\n- `load_recv(json_values: dict) -> User`: Loads the user data from the provided JSON values.\n\n## Conclusion\n\nThis documentation provided an overview of the Signal-Cli library and its usage. It covered account registration, sending and receiving messages, retrieving user status, and included a class reference for the main classes in the library. Refer to the examples and class reference for detailed usage instructions.\n",
    'author': 'Vortex5ROot',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
